# Multiple Locations Example

This deploys the module into multiple regions, as specified by the user
