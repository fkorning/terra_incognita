# Footer content for the named values example
