# Default example

This deploys the module with system assigned managed identity enabled.
