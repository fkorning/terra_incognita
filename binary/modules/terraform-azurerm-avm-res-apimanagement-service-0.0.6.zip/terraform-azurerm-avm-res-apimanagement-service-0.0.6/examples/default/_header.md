# Default example

This deploys the module in its simplest form.
