# Simple example for the Azure Virtual Network module

This shows how to create and manage Azure Virtual Networks (vNets) using the minimal, default values from the module.
