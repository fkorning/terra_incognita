# Example of associating Network Security Groups with Azure Virtual Network subnet

This code sample shows how to create and manage Azure Virtual Networks (vNets) and associate Netwrok Security Groups.
