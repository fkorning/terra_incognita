# Peer only specified subnets example for Azure Virtual Network module

This sample shows how to create peerings only for specific subnets in a virtual network.
