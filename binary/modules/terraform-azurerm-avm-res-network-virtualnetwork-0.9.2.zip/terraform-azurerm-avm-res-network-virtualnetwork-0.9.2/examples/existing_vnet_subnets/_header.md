# Example of Subnets with pre-existing virtual networks

This code sample shows how to create and manage subnets for pre-existing virtual networks.
