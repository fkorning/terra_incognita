# Example of Virtual Network peering with pre-existing virtual networks

This code sample shows how to create and manage peerings for pre-existing virtual networks.
