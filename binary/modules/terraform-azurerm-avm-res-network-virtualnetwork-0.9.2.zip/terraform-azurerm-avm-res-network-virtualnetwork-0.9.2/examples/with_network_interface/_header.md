# Example with network interface

This shows what happens if you associate a NIC with a subnet and tests for idempotency.
