# Peer only specified address spaces example for Azure Virtual Network module

This sample shows how to create peerings only for specific address spaces in a virtual network.
