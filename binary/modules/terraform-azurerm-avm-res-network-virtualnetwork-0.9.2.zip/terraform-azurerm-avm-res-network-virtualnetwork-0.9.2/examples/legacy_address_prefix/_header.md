# Example of using teh singular address prefix on a subnet

Some Azure resource types don't support the addressPrefix array, so we need to support the singular option too.
