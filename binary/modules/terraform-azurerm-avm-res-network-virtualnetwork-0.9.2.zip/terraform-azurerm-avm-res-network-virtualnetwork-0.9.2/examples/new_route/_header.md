# Example of creating route tables and associating them with subnets

This code sample shows how to create and manage Azure Virtual Networks (vNets) and associate route tables.
