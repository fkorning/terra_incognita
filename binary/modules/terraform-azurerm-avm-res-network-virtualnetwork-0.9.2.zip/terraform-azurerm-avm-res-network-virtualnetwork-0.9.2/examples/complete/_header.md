# Complete example for Azure Virtual Network module

This sample shows how to create and manage Azure Virtual Networks (vNets) and their associated resources with all options enabled.
