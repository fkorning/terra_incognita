# Sub-modules

Create directories for each sub-module if required.
README.md files will be automatically generated for each sub-module using `terraform-docs`.
